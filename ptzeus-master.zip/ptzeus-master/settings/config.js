const config = {
        botName: 'Zeusbot',
        ownerName: 'Zeus',
}
