const zeusmenu = (prefix, pushname) => {
    return `❍ *Comandos do Zeus*
    
    ║➩ ❍ ${prefix}setprefix
    ║➩ ❍ ${prefix}block
    ║➩ ❍ ${prefix}tm
    ║➩ ❍ ${prefix}tmctt
    ║➩ ❍ ${prefix}clearall`

}

exports.zeusmenu = zeusmenu